@echo off
cd /d "%~dp0"
:: ============================================================
:: Request Administrator Privileges
:: ============================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo Running with administrator privileges...
echo -----------------------------------------

:: ============================================================
:: LOOP เฉพาะตอนมีอัปเดต
:: ============================================================
:update_loop

echo Checking for update...
python -OO -B start.py True
set exitcode=%ERRORLEVEL%

echo Exit code from Python = %exitcode%

:: ถ้า exit code = 9 → มีอัปเดต
if %exitcode%==9 (
    echo -----------------------------------------
    echo Update detected. Extracting update.zip...
    echo -----------------------------------------

    powershell -command "Expand-Archive -Force 'update.zip' '.'; Remove-Item 'update.zip' -Force"


    echo Extraction complete.
    echo Restarting update check...
    goto update_loop
)

pause
exit /b
