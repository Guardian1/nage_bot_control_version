# start.py
import os
import sys
import json
import time
import zipfile
import requests
from main import main as bot  # import UI จาก main.py

# -----------------------------
# ตั้งค่าพื้นฐาน
# -----------------------------

VERSION_JSON_URL = "https://raw.githubusercontent.com/Guardian1/nage_bot_control_version/refs/heads/main/version.json"

# -----------------------------
# ฟังก์ชันดาวน์โหลดไฟล์ทั่วไป
# -----------------------------


def download_file(url, save_path, retry=3):
    """
    ดาวน์โหลดไฟล์จาก URL แล้วเซฟเป็น save_path
    มี retry กันเน็ตหลุดชั่วคราว + log ชัดเจน
    """
    for attempt in range(1, retry + 1):
        try:
            print(f"[Download] Attempt {attempt}/{retry} → {url}")
            r = requests.get(
                url,
                timeout=10,
                headers={
                    "Cache-Control": "no-cache",
                    "Pragma": "no-cache",
                    "Expires": "0"
                }
            )

            r.raise_for_status()

            # กันกรณี OneDrive ส่งหน้าเว็บแทนไฟล์จริง
            if (
                r.text.strip().startswith("<!DOCTYPE html>")
                or "<html" in r.text.lower()
            ):
                print(
                    "[Error] Received HTML instead of file data — check OneDrive link."
                )
                print("Preview:")
                print(r.text[:300])
                return False

            with open(save_path, "wb") as f:
                f.write(r.content)

            print(f"[Download] Success → saved to {save_path}")
            return True

        except requests.exceptions.Timeout:
            print(f"[Error] Timeout (attempt {attempt})")
        except requests.exceptions.HTTPError as e:
            print(f"[Error] HTTP error: {e}")
        except requests.exceptions.ConnectionError as e:
            print(f"[Error] Connection error: {e}")
        except Exception as e:
            print(f"[Error] Unexpected error: {e}")

        time.sleep(1)

    print("[Download] Failed after all retries.")
    return False


# -----------------------------
# อ่านเวอร์ชันปัจจุบันในเครื่อง
# -----------------------------


def get_local_version():
    if not os.path.exists("version_local.txt"):
        return "0.0.0"

    with open("version_local.txt", "r", encoding="utf-8") as f:
        return f.read().strip()


# -----------------------------
# ดาวน์โหลด version.json
# -----------------------------


def download_version_info():
    ok = download_file(VERSION_JSON_URL, "version.json")
    if not ok:
        print("Cannot download version info")
        sys.exit(0)

    with open("version.json", "r", encoding="utf-8") as f:
        return json.load(f)


# -----------------------------
# เปรียบเทียบเวอร์ชัน
# -----------------------------


def is_newer_version(local, remote):
    return local != remote


# -----------------------------
# ดาวน์โหลด ZIP อัปเดต
# -----------------------------


def download_update_zip(url):
    ok = download_file(url, "update.zip")
    if not ok:
        print("Cannot download update zip")
        sys.exit(0)


# -----------------------------
# ระบบ Auto-Update (เวอร์ชันใหม่)
# -----------------------------

def update_local_version(version):
    """
    เขียนเลขเวอร์ชันลงไฟล์ version_local.txt
    ถ้าไม่มีไฟล์จะสร้างใหม่ทันที
    """
    try:
        with open("version_local.txt", "w", encoding="utf-8") as f:
            f.write(version)
        print(f"[Version] Updated local version to {version}")
    except Exception as e:
        print(f"[Version] Failed to update local version: {e}")


def auto_update(auto_update_enabled=True):
    print("[Auto-Update] Checking version...")

    local_version = get_local_version()
    version_info = download_version_info()

    remote_version = version_info["version"]
    url_zip = version_info["url"]

    print(f"Local version : {local_version}")
    print(f"Remote version: {remote_version}")

    if is_newer_version(local_version, remote_version):
        print("New version found, downloading update...")
        download_update_zip(url_zip)
        update_local_version(remote_version)

        print("Download complete. Returning exit code 9...")
        sys.exit(9)  # ให้ BAT เป็นคน unzip
    else:
        print("No update available.")
        # sys.exit(0)


# -----------------------------
# main flow
# -----------------------------


def main(auto_update_enabled=True):
    if auto_update_enabled:
        auto_update(auto_update_enabled)

    print("Running current version...")
    local_version = get_local_version()
    version_info = download_version_info()

    remote_version = version_info["version"]

    print(f"Local version : {local_version}")
    print(f"Remote version: {remote_version}")

    if not is_newer_version(local_version, remote_version):
        bot()

    bot()


if __name__ == "__main__":

    is_pythonw = sys.executable.lower().endswith("pythonw.exe")
    # is_python  = sys.executable.lower().endswith("python.exe")

    # ถ้ามี argument → ใช้ค่าที่ส่งเข้ามา
    # ถ้าไม่มี → default = False
    # if is_pythonw:
    #     flag = sys.argv[1] == "True"
    # else:
    #     flag = False
    print(f"Running with pythonw: {is_pythonw}")

    flag =  is_pythonw

    main(auto_update_enabled=flag)
