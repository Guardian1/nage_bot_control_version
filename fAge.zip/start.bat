@echo off
cd /d "%~dp0"



:: ============================================================
:: Request Administrator Privileges
:: ============================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)


:: =========================
:: Install Requirements
:: =========================
echo Checking and installing required modules...

python -m pip install --upgrade pip
python -m pip install -r requirements.txt

python -m pip install keyboard==0.13.5
python -m pip install mss==10.2.0
python -m pip install opencv-python==5.0.0.93
python -m pip install pynput==1.8.2
python -m pip install pywinauto==0.6.9
python -m pip install requests==2.34.2
python -m pip install cryptography==49.0.0
python -m pip install customtkinter==6.0.0
python -m pip install PySide6==6.11.1


:: ============================================================
:: CHECK UPDATE ครั้งแรก
:: ============================================================
python -OO -B start.pyw
set exitcode=%ERRORLEVEL%

:: ============================================================
:: ถ้า exit code = 9 → มีอัปเดต
:: ============================================================
if %exitcode%==9 (
    powershell -command "Expand-Archive -Force 'update.zip' '.'; Remove-Item 'update.zip' -Force"
)

:: ============================================================
:: เรียก start.pyw อีกครั้งหลังอัปเดต (หรือไม่มีอัปเดต)
:: ============================================================
start "" pythonw.exe -OO -B start.pyw





